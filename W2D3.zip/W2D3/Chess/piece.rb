class Piece
    def initialize
       
    end

    def inspect
        "Piece"
    end
end